
    suppressPackageStartupMessages(library(parallel))
    suppressPackageStartupMessages(library(Rcpp))
    dirx="/home/sokol/.local/lib/python3.7/site-packages/influx_si/R"
    source(file.path(dirx, "opt_cumo_tools.R"))
    doit=function(fR) {
       f=substr(fR, 1, nchar(fR)-2)
       nm_flog=sprintf("%s.log", f)
       nm_ferr=sprintf("%s.err", f)
       fshort=basename(f)
       now=Sys.time()
       flog=file(nm_flog, "a")
       cat("calcul  : ", format(now, "%Y-%m-%d %H:%M:%S"), "\n", sep="", file=flog)
       close(flog)
       source(fR)
       now=Sys.time()
       flog=file(nm_flog, "a")
       cat("end     : ", format(now, "%Y-%m-%d %H:%M:%S"), "\n", sep="", file=flog)
       if (file.info(nm_ferr)$size > 0) {
           cat("=>Check ", nm_ferr, "\n", sep="", file=flog)
       }
       close(flog)
       return(retcode)
    }
    # build dyn lib
    nodes=2
    type="PSOCK"
    cl=makeCluster(nodes, type)
    flist=c("e_coli_growth.R", "e_coli.R")
    retcode=max(unlist(parLapply(cl, flist, doit)))
    stopCluster(cl)
    q("no", status=retcode)
